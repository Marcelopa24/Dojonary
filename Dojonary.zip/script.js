function change(element) {
    element.innerText = "Log Out";
}

function hide(element) {
    element.remove();
}

function mensaje(){
    alert("Ninja was liked!!");
}